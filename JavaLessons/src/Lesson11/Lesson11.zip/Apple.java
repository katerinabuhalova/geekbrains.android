package Lesson11;

public class Apple extends Fruit {

    public Apple(int weightOneFruit) {
        super(weightOneFruit);
    }
}
