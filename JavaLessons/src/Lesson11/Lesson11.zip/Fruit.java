package Lesson11;

public class Fruit {
    private int weightOneFruit;

    public Fruit(int weightOneFruit) {
        this.weightOneFruit = weightOneFruit;
    }

    public int getWeight() {
        return weightOneFruit;
    }
}
