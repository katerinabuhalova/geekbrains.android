package lesson8;

public interface PhysicalAction {
    boolean run(int length);
    boolean jump(int height);
}
