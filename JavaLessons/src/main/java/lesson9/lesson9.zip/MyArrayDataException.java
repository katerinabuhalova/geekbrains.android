package lesson9;

public class MyArrayDataException  extends Exception {


    public MyArrayDataException(String message){
        super(message);

    }
}
