package lesson9;

public class MyArraySizeException extends Exception{

  public   MyArraySizeException(){
      super("Не правильно задан размер массива!");
  }
}
