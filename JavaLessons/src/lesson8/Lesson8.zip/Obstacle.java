package lesson8;

public interface Obstacle {

    boolean pass(PhysicalAction physicalAction);
}
