package Lesson11;

public class Orange extends Fruit {

    public Orange(int weightOneFruit) {
        super(weightOneFruit);
    }
}
